//
//  ImageUX.swift
//  mySecondApp
//
//  Created by Alumno on 07/10/22.
//

import UIKit

class ImageUX:UIViewController{
    override func viewDidLoad() {
        super.viewDidLoad()
        //Do any additional setup after the view
    }
    @IBAction func backButton(_ sender: Any) {
        self.dismiss(animated: true)
    }
}

