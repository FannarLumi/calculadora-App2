//
//  ViewController.swift
//  mySecondApp
//
//  Created by Alumno on 30/09/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var numeroUno: UITextField!
    @IBOutlet weak var numeroDos: UITextField!
    var titulo : String = ""
    
    
    
    
    @IBAction func dividir(_ sender: Any) {
        /*let dividendo = numeroUno.text
        let divisor = numeroDos.text*/
        
        //No deja que el usuario lo ponga vacìo o algo asi
        //var mensaje = "Favor de completar ambos campos."
        //do{
        let dividendoUno = Float(numeroUno.text!)
        let divisorUno = Float(numeroDos.text ?? "0")
        var message = "Favor de completar ambos campos"
        if(dividendoUno != nil && divisorUno != nil){
            let resultado = (dividendoUno ?? 0)/(divisorUno ?? 0)
            message = String(resultado)
        }
        //MostrarAlerta(message: message, titulo: "Divisiòn")
        titulo = "Divisiòn 2"
        MostrarAlerta(valor: message)
        
    }
    @IBAction func suma(_ sender: Any) {
        let dividendoUno = Float(numeroUno.text!)
        let divisorUno = Float(numeroDos.text ?? "0")
        var message = "Favor de completar ambos campos"
        if(dividendoUno != nil && divisorUno != nil){
            let resultado = (dividendoUno ?? 0)+(divisorUno ?? 0)
            message = String(resultado)
        }
        MostrarAlerta(message: message, titulo: "Suma")
        
    }
    @IBAction func multiplicacion(_ sender: Any) {
        let dividendoUno = Float(numeroUno.text!)
        let divisorUno = Float(numeroDos.text ?? "0")
        var message = "Favor de completar ambos campos"
        if(dividendoUno != nil && divisorUno != nil){
            let resultado = (dividendoUno ?? 0)*(divisorUno ?? 0)
            message = String(resultado)
        }
        MostrarAlerta(message: message, titulo: "Multiplicaciòn")
        
    }
    @IBAction func resta(_ sender: Any) {
        let dividendoUno = Float(numeroUno.text!)
        let divisorUno = Float(numeroDos.text ?? "0")
        var message = "Favor de completar ambos campos"
        if(dividendoUno != nil && divisorUno != nil){
            let resultado = (dividendoUno ?? 0)-(divisorUno ?? 0)
            message = String(resultado)
        }
        MostrarAlerta(message: message, titulo: "Resta")
        
    }
    
    
    
    
    @IBAction func buttonOneClick(_ sender: Any) {
        MostrarAlerta(message: userTextField.text!, titulo: "Alert!")
    }
    
    
    @IBOutlet weak var userTextField: UITextField!
    
    @IBOutlet weak var titleText: UILabel!
    @IBOutlet weak var passwordTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        titleText.text = "Segunda Aplicacion"
        titleText.textColor = UIColor(red: 36/255, green: 80/255, blue: 95/255, alpha: 1.0)
    }
    
    func MostrarAlerta(message: String, titulo:String){
        let alert = UIAlertController(title:titulo, message:message, preferredStyle:UIAlertController.Style.alert)
        
        alert.addAction(UIAlertAction(title:"Close", style: UIAlertAction.Style.cancel))
        self.present(alert, animated: true, completion: nil)
    }
    func MostrarAlerta(valor:String){
        MostrarAlerta(message: valor, titulo: self.titulo)
    }
    @IBAction func navegarImagen(_ sender: Any) {
        let storyBoard = UIStoryboard(name:"Main", bundle:nil)
        let imagenViewController = storyBoard.instantiateViewController(withIdentifier: "ImageUX")
        self.present(imagenViewController,animated: true)
    }
    
}

