//
//  SwiftUIViewImage.swift
//  mySecondApp
//
//  Created by Alumno on 07/10/22.
//

import SwiftUI

struct SwiftUIViewImage: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct SwiftUIViewImage_Previews: PreviewProvider {
    static var previews: some View {
        SwiftUIViewImage()
    }
}
